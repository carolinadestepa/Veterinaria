﻿$(document).ready(function () {

    $(".btMenu").hover(
        function () {
            $(this).css('font-weight', 'bold');
        }, function () {
            $(this).css('font-weight', 'normal');
        }
    );

});